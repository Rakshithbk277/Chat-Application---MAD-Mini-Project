package com.example.chatapp2.listeners;

import com.example.chatapp2.models.User;

public interface UserListener {

    void onUserClicked(User user);
}
