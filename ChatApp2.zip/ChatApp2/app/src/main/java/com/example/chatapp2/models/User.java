package com.example.chatapp2.models;

import java.io.Serializable;

public class User implements Serializable{
    public String name,image,email,token,id;
}


