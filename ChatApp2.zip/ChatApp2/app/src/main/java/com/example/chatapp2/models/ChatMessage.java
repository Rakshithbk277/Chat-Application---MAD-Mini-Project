package com.example.chatapp2.models;

import java.util.Date;

public class ChatMessage {

    public String senderId , receiverId , message , dateTime;
    public Date dateObj;
    public String conversionId, conversationName, conversionImage;
}
